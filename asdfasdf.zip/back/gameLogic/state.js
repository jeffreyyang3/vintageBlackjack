import { Card, Deck, Hand } from "./Cards";
import { Player } from "./Player";

const deck = new Deck();

const hand = new Hand();
